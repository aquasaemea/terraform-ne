import os
import boto3
import subprocess

def handler(event, context):
    lambda_behavior = os.environ.get("LAMBDA_BEHAVIOUR")

    # Get the S3 bucket and key (object key) from the event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    # Create an S3 client
    s3 = boto3.client('s3')

    # Download the file from S3
    local_file_path = '/tmp/' + key
    s3.download_file(bucket, key, local_file_path)

    if lambda_behavior == "block":
        # Change permissions and execute the file
        try:
            subprocess.run(['chmod', '+x', local_file_path])  # Make the file executable
            result = subprocess.run([local_file_path], capture_output=True, text=True, shell=True)
            output = result.stdout
        except subprocess.CalledProcessError as e:
            output = f"Blocked: {e}"
    elif lambda_behavior == "detect":
        # Read and print the content of the file
        with open(local_file_path, 'r') as file:
            file_content = file.read()
            output = f"Content of {key}:\n{file_content}"
    else:
        output = "Invalid LAMBDA_BEHAVIOUR value"

    # Print the result
    print(output)

    return {
        'statusCode': 200,
        'body': 'Processing complete'
    }


