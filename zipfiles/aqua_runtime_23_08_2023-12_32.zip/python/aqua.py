import os
from ctypes import cdll

aqua_nanoenforcer_dir = os.environ.get("AQUA_NANOENFORCER_DIR", "/opt/aquasec")
lambda_hooks_path = os.environ.get("AQUA_LAMBDA_HOOKS", aqua_nanoenforcer_dir + "/lambda-hooks.so")
slklib_debug = os.environ.get("SLKLIB_DEBUG", 0)

if slklib_debug:
    print("AQUA nano-enforcer, PID: " + str(os.getpid()))
    print("AQUA lambda hook: " + lambda_hooks_path)

aqua_lib = cdll.LoadLibrary(lambda_hooks_path)

